package br.com.hair2u.app

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import kotlinx.android.synthetic.main.login.*
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.core.view.GravityCompat
import com.google.android.material.navigation.NavigationView
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.toolbar.*

class MainActivity : DebugActivity(), NavigationView.OnNavigationItemSelectedListener {


    private fun configuraMenuLateral() {
        var toogle = ActionBarDrawerToggle (
            this,
            layoutMenuLateral,
            toolbar,
            R.string.drawer_open,
            R.string.drawer_close
        )
        layoutMenuLateral.addDrawerListener(toogle)
        toogle.syncState()

        menu_lateral.setNavigationItemSelectedListener(this)
    }


    override fun onNavigationItemSelected(item: MenuItem): Boolean {

        when (item.itemId) {
            R.id.nav_servicos -> {
                Toast.makeText(this, "Clicou Servicos", Toast.LENGTH_SHORT).show()
            }
            R.id.nav_produtos -> {
                Toast.makeText(this, "Clicou Produtos", Toast.LENGTH_SHORT).show()
            }
            R.id.nav_profissional -> {
                Toast.makeText(this, "Clicou Profissional", Toast.LENGTH_SHORT).show()
            }
        }
        layoutMenuLateral.closeDrawer(GravityCompat.START)
        return true
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)
        imageView5.setImageResource(R.drawable.cab)

        botao_login.setOnClickListener{
            val user  = input_user.text.toString()
            val password = input_password.text.toString()
            var intent = Intent(this, HomeActivity::class.java)
            var parametros = Bundle()
            parametros.putString("usuario", user)
            parametros.putString("senha", password)
            if (user.equals("") && password.equals("")){
                Toast.makeText(this, "Campos Usuário e Senha vazios!", Toast.LENGTH_LONG).show()
            } else if (user.equals("aluno") && password.equals("impacta")){
                Toast.makeText(this, "Login Efetuado com Sucesso!", Toast.LENGTH_SHORT).show()
                intent.putExtras(parametros)
                //intent.putExtra("double", 1.75)
                startActivity(intent)
            } else{Toast.makeText(this, "Usuário ou senha incorretos", Toast.LENGTH_LONG).show() }
            configuraMenuLateral()
        }
    }

}