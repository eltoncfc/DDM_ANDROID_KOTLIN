package br.com.hair2u.app

import android.app.SearchManager
import android.content.Context

import android.widget.SearchView
import kotlinx.android.synthetic.main.activity_home.*
import kotlinx.android.synthetic.main.login.*
import kotlinx.android.synthetic.main.toolbar.*
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.core.view.GravityCompat
import com.google.android.material.navigation.NavigationView
import kotlinx.android.synthetic.main.activity_main.*


class HomeActivity : DebugActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val args = intent.extras
        val usuario = args?.getString("usuario")
        val numero = args?.getString("senha")

        Toast.makeText(this, usuario, Toast.LENGTH_SHORT).show()
        Toast.makeText(this, numero, Toast.LENGTH_SHORT).show()

        user_home.text = "Bem-vindo $usuario"


        button_home.setOnClickListener{
            var intent_home = Intent(this, MainActivity::class.java)
            startActivity(intent_home)
        }

    }

       override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.nav_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId){
            R.id.nav_bar_search -> Toast.makeText(this,"Pesquisar",Toast.LENGTH_SHORT).show()
            R.id.nav_bar_update -> Toast.makeText(this,"Atualizar",Toast.LENGTH_SHORT).show()
            R.id.nav_bar_add -> Toast.makeText(this,"Adicionar",Toast.LENGTH_SHORT).show()
        }
        return super.onOptionsItemSelected(item)

    }
}